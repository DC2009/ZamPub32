[MainWindow]
Create=1
Visible=1
State=0
Left=0
Top=0
Width=648
Height=97

[PropertyInspector]
Create=1
Visible=1
State=0
Left=0
Top=99
Width=190
Height=402

[AlignmentPalette]
Create=0

[ProjectManager]
Create=0

[WatchWindow]
Create=1
Visible=1
State=0
Left=5
Top=473
Width=421
Height=126

[BreakpointWindow]
Create=0

[CallStackWindow]
Create=0

[Components]
Create=0

[History_14]
Count=32
H0=OldPwdEdit.Text
H1=UserEdit.Text
H2=PasswordEdit.Text
H3=UserName.Text
H4=p^.FPwd
H5=p^.FName
H6=Ok
H7=DR.FTenders
H8=DR.FPath
H9=d^.FPath
H10=Dir
H11=Tenders
H12=d^.FTenders
H13=Index
H14=i
H15=UR.FDBCnt
H16=MaxUsers
H17=UR.FName
H18=UR.FDBList^.FPath
H19=p^.FDBList^.FPath
H20=p^.FDbCnt
H21=Rights and rRead
H22=rRead
H23=(Rights and rRead)>0
H24=Rights
H25=CurDir
H26=TabListBox1.Items[i]
H27=Directory
H28=c
H29=PwdEdit2.Text
H30=PwdEdit1.Exit
H31=PwdEdit1.Text

[History_19]
Count=32
H0=c:\modem\readme
H1=c:\zampub2\userunit.pas
H2=c:\zampub2\s2usri.pas
H3=c:\zampub2\chgdb.pas
H4=c:\zampub2\pwdman.pas
H5=c:\zampub2\chgpwd.pas
H6=c:\zampub2\passwd.pas
H7=c:\zampub2\ti2803.asc
H8=c:\zampub2\crypt.pas
H9=c:\delphi\telesoft\lbtab.pas
H10=c:\zampub2\utils.pas
H11=c:\zampub2\siwzini.pas
H12=c:\delphi\source\vcl\classes.pas
H13=c:\zampub2\secfile.pas
H14=c:\zampub2\winpwd.pas
H15=c:\zampub2\przadm.pas
H16=c:\zampub2\dbprze.pas
H17=c:\zampub2\dbuser.pas
H18=c:\zampub2\dbadm.pas
H19=c:\zampub2\msg2.pas
H20=c:\zampub2\userrec.pas
H21=c:\zampub2\prolog.pas
H22=c:\zampub2\siwz1.pas
H23=c:\zampub2\typzam.pas
H24=c:\zampub2\amount.pas
H25=c:\zampub2\about.pas
H26=c:\zampub2\mainmenu.pas
H27=c:\projects\zlecenie\druki\wniosek.txt
H28=c:\projects\zlecenie\druki\regulam.txt
H29=c:\projects\zlecenie\druki\drpomlst.txt
H30=c:\projects\zlecenie\druki\decyzja.txt
H31=c:\delphi\hasp\read.me

[History_37]
Count=32
H0=c:\zampub2\s2usri.pas
H1=c:\zampub2\unit1.pas
H2=c:\zampub2\userdata.pas
H3=c:\zampub2\chgpwd.pas
H4=c:\zampub2\secfile.pas
H5=c:\zampub2\useredit.pas
H6=c:\zampub2\newusr.pas
H7=c:\zampub2\usradm.pas
H8=c:\zampub2\przusr.pas
H9=c:\zampub2\przadm.pas
H10=c:\zampub2\admutil.pas
H11=c:\zampub2\dbprze.pas
H12=c:\zampub2\dbadd.pas
H13=c:\zampub2\dbadm.pas
H14=c:\zampub2\userunit.pas
H15=c:\zampub2\userrec.pas
H16=c:\zampub2\dbuser.pas
H17=c:\zampub2\dbdlgu.pas
H18=c:\zampub2\dbdlg.pas
H19=c:\zampub2\pwdman.pas
H20=c:\zampub2\unit2.pas
H21=c:\zampub2\crypt.pas
H22=c:\zampub2\passwd.pas
H23=c:\zampub2\msg2.pas
H24=c:\projects\zlecenie\hasputil.pas
H25=c:\delphi\hasp\hasputil.pas
H26=c:\projects\zlecenie\hasp.pas
H27=c:\projects\zlecenie\drzallst.txt
H28=c:\projects\zlecenie\drpomlst.txt
H29=c:\projects\zlecenie\drobolst.txt
H30=c:\projects\zlecenie\drklst.txt
H31=c:\projects\zlecenie\drukilst.txt

[Closed Files]
File_0=C:\MODEM\README,1,1,1,1
File_1=C:\ZAMPUB2\CHGDB.PAS,1,55,1,67
File_2=C:\ZAMPUB2\CHGPWD.PAS,1,54,1,58
File_3=C:\ZAMPUB2\PASSWD.PAS,1,70,1,78
File_4=C:\ZAMPUB2\PWDMAN.PAS,1,21,1,30
File_5=C:\ZAMPUB2\USERUNIT.PAS,1,70,1,83
File_6=C:\ZAMPUB2\S2USRI.PAS,1,94,1,108
File_7=C:\ZAMPUB2\UNIT1.PAS,1,1,1,1
File_8=C:\ZAMPUB2\USERDATA.PAS,1,6,1,15
File_9=C:\ZAMPUB2\SIWZINI.PAS,1,101,40,117

[Modules]
Count=1
Module0=C:\ZAMPUB2\README
EditWindowCount=1

[Form0]
FormState=0

[EditWindow0]
Create=1
Visible=1
State=0
Left=210
Top=119
Width=430
Height=300
ViewCount=1
CurrentView=0
View0=0

[View0]
Module=0
CursorX=1
CursorY=1
TopLine=1
LeftCol=1

[Watches]
Count=0

[Breakpoints]
Count=0
